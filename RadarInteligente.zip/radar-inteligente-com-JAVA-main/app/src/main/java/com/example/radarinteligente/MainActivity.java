package com.example.radarinteligente;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {//Começo do código

    //Variaveis sendo iniciadas
    EditText editVelocidade, editAcidente;
    Button btnVerificar;
    TextView textResultado;

    //instanciar classe
    RadarInteligente radarInteligente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Inicialização dos componentes, xml
        editVelocidade = findViewById(R.id.editVelocidade);
        editAcidente = findViewById(R.id.editAcidente);
        btnVerificar = findViewById(R.id.btnVerificar);
        textResultado = findViewById(R.id.textResultado);

        //Carregar as velocidades existentes
        VelocidadeDao.carregarVelocidades();

        //Instância
        radarInteligente = new RadarInteligente();
        radarInteligente.calcularVelocidadeMediaSemAcidente();

        //Configurando o botão
        btnVerificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String velocidadeStr = editVelocidade.getText().toString();
                String acidenteStr = editAcidente.getText().toString();

                //Função para verificar se os campos não estão vazios
                if (!velocidadeStr.isEmpty() && !acidenteStr.isEmpty()) {
                    float velocidade = Float.parseFloat(velocidadeStr);
                    boolean acidente = acidenteStr.equals("1");

                    //Cadastrar a nova velocidade e o acidente
                    VelocidadeDao.cadastrarVelocidade(velocidade, acidente);

                    //Atualizando a média de velocidade sem acidente
                    radarInteligente.calcularVelocidadeMediaSemAcidente();

                    //Função para verificar se a velocidade é permitida
                    if (radarInteligente.velocidadePermitida(velocidade)) {
                        textResultado.setText("Velocidade permitida. Velocidade média permitida: " + radarInteligente.getVelocidadeMediaSemAcidente() + " Km/h");
                    } else {
                        textResultado.setText("Multado! Velocidade excedida. Velocidade média permitida: " + radarInteligente.getVelocidadeMediaSemAcidente() + " Km/h");
                    }
                } else {
                    textResultado.setText("Por favor, insira todos os dados.");
                }
            }
        });

    }//fim do código
}
